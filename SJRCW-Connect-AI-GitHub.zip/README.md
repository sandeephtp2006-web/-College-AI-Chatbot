# SJRCW Connect AI

A responsive college website for St. Joseph's Research Centre for Women (SJRCW), featuring an AI-style admission assistant chatbot.

## Features

- Responsive website layout for desktop and mobile
- Admission assistant chatbot with frequently asked questions
- College overview and campus information
- Courses and admissions sections
- Contact information and enquiry section
- React component-based frontend

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui and Radix UI
- Lucide React

## Requirements

- Node.js 20.19+ or 22.12+
- npm

## Run locally

1. Clone the repository:

   ```bash
   git clone https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   cd YOUR-REPOSITORY
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Start the development server:

   ```bash
   npm run dev
   ```

4. Open the local URL printed in your terminal (usually `http://localhost:5173`).

## Available scripts

| Command | Description |
|---|---|
| `npm run dev` | Start the Vite development server |
| `npm run build` | Create a production build in `dist/` |
| `npm run preview` | Preview the production build |
| `npm run lint` | Run ESLint |
| `npm test` | Run tests once |

## Project structure

```text
src/
  assets/       Images used by the website
  components/   Reusable website sections and chatbot
  hooks/        Custom React hooks
  lib/          Shared utilities
  pages/        Page components
  App.tsx       Main application component
  main.tsx      Application entry point
public/         Static public assets
```

## GitHub upload

This repository package excludes `node_modules/` and generated `dist/` files. GitHub does not need these folders; dependencies are restored with `npm install` and production files are generated with `npm run build`.

Before publishing, confirm that you have permission to share the college branding, images, text, and any third-party assets included in this project. Do not commit passwords, API keys, access tokens, or private environment files.

## License

No open-source license is included. Add a license only if you have permission to distribute this project under its terms.
