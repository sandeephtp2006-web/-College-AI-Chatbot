import { BookOpen, FlaskConical, Briefcase, Palette, Monitor, Calculator } from "lucide-react";

const courses = [
  { icon: BookOpen, title: "B.A. (Hons)", desc: "English, History, Economics, Psychology, Journalism", duration: "3 Years" },
  { icon: FlaskConical, title: "B.Sc.", desc: "Physics, Chemistry, Mathematics, Biotechnology, Computer Science", duration: "3 Years" },
  { icon: Briefcase, title: "B.Com", desc: "Accounting, Finance, Taxation, Business Management", duration: "3 Years" },
  { icon: Monitor, title: "BCA", desc: "Computer Applications, Software Development, Data Science", duration: "3 Years" },
  { icon: Palette, title: "B.A. Visual Arts", desc: "Fine Arts, Design, Digital Media, Animation", duration: "3 Years" },
  { icon: Calculator, title: "M.Com / M.Sc", desc: "Postgraduate programs in Commerce & Sciences", duration: "2 Years" },
];

const CoursesSection = () => {
  return (
    <section id="courses" className="section-padding bg-muted">
      <div className="container-college">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-secondary font-semibold text-sm uppercase tracking-wider">Our Programs</span>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
            Discover Your Path
          </h2>
          <p className="text-muted-foreground">
            Choose from a wide range of undergraduate and postgraduate programs designed to prepare you for a successful career.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <div
              key={course.title}
              className="group bg-card rounded-xl p-6 hover:shadow-lg transition-all duration-300 border border-border hover:border-secondary/40"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-secondary/20 transition-colors">
                <course.icon className="w-6 h-6 text-primary group-hover:text-secondary transition-colors" />
              </div>
              <h3 className="font-heading text-xl font-bold text-card-foreground mb-2">{course.title}</h3>
              <p className="text-muted-foreground text-sm mb-4">{course.desc}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-secondary bg-secondary/10 px-3 py-1 rounded-full">
                  {course.duration}
                </span>
                <a href="#admissions" className="text-primary text-sm font-medium hover:text-secondary transition-colors">
                  Apply →
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CoursesSection;
