import { GraduationCap } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-12 px-4 md:px-8">
      <div className="container-college">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-7 h-7 text-secondary" />
            <span className="font-heading text-lg font-bold">SJRCW College</span>
          </div>
          <div className="flex flex-wrap gap-6 text-sm text-primary-foreground/60">
            <a href="#home" className="hover:text-secondary transition-colors">Home</a>
            <a href="#about" className="hover:text-secondary transition-colors">About</a>
            <a href="#courses" className="hover:text-secondary transition-colors">Courses</a>
            <a href="#admissions" className="hover:text-secondary transition-colors">Admissions</a>
            <a href="#contact" className="hover:text-secondary transition-colors">Contact</a>
          </div>
        </div>
        <div className="border-t border-primary-foreground/10 mt-8 pt-6 text-center text-sm text-primary-foreground/40">
          © {new Date().getFullYear()} SJRCW College. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
