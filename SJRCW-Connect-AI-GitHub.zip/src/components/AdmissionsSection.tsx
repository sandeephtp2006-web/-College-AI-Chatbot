import { FileText, ClipboardCheck, CreditCard, PartyPopper } from "lucide-react";

const steps = [
  { icon: FileText, step: "01", title: "Fill Application", desc: "Complete the online application form with your details and academic records." },
  { icon: ClipboardCheck, step: "02", title: "Submit Documents", desc: "Upload marksheets, ID proof, passport photos and other required documents." },
  { icon: CreditCard, step: "03", title: "Pay Fees", desc: "Pay the application fee online or at the college counter." },
  { icon: PartyPopper, step: "04", title: "Get Admitted!", desc: "Receive your admission confirmation and welcome to SJRCW College!" },
];

const AdmissionsSection = () => {
  return (
    <section id="admissions" className="section-padding bg-background">
      <div className="container-college">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-secondary font-semibold text-sm uppercase tracking-wider">Admissions</span>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
            How to Apply
          </h2>
          <p className="text-muted-foreground">
            Follow these simple steps to begin your journey at SJRCW College. Need help? Use our AI Admission Assistant chatbot!
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((s, i) => (
            <div key={s.step} className="relative text-center">
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-[60%] w-[80%] h-0.5 bg-border" />
              )}
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 relative">
                <s.icon className="w-8 h-8 text-primary" />
                <span className="absolute -top-1 -right-1 w-7 h-7 rounded-full bg-secondary text-secondary-foreground text-xs font-bold flex items-center justify-center">
                  {s.step}
                </span>
              </div>
              <h3 className="font-heading text-lg font-bold text-foreground mb-2">{s.title}</h3>
              <p className="text-muted-foreground text-sm">{s.desc}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href="https://wa.me/919876543210?text=Hi%2C%20I%20want%20to%20know%20about%20admissions%20at%20SJRCW%20College"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-college-green text-primary-foreground px-7 py-3.5 rounded-xl font-semibold hover:brightness-110 transition-all shadow-lg"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
};

export default AdmissionsSection;
