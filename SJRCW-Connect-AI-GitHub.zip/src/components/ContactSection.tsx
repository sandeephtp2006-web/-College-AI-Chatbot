import { MapPin, Phone, Mail, Clock } from "lucide-react";

const contactInfo = [
  { icon: MapPin, title: "Address", text: "SJRCW College, Near Sujatha Talkies, Rajajinagar, Bangalore, Karnataka, India" },
  { icon: Phone, title: "Phone", text: "+91 98765 43210" },
  { icon: Mail, title: "Email", text: "admissions@sjrcw.edu.in" },
  { icon: Clock, title: "Office Hours", text: "Mon – Sat, 9:00 AM – 5:00 PM" },
];

const ContactSection = () => {
  return (
    <section id="contact" className="section-padding bg-muted">
      <div className="container-college">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-secondary font-semibold text-sm uppercase tracking-wider">Contact</span>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
            Get in Touch
          </h2>
          <p className="text-muted-foreground">
            Have questions? Reach out to us or use the AI chatbot for instant answers.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {contactInfo.map((item) => (
            <div
              key={item.title}
              className="bg-card rounded-xl p-6 text-center border border-border"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <item.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-heading font-bold text-card-foreground mb-1">{item.title}</h3>
              <p className="text-muted-foreground text-sm">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
