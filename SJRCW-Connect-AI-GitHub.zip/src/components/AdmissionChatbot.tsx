import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";

type Message = {
  role: "user" | "bot";
  text: string;
};

const WHATSAPP_LINK = "https://wa.me/919876543210?text=Hi%2C%20I%20need%20help%20with%20admissions%20at%20SJRCW%20College";

const FAQ: Record<string, string> = {
  "admission": "📋 **Admissions are open for 2025-26!**\n\nSteps:\n1. Fill the online application form\n2. Submit documents (marksheets, ID, photos)\n3. Pay the application fee\n4. Get your admission confirmation!\n\nWant to apply now? Visit the Admissions section or chat with us on WhatsApp!",
  "courses": "📚 **We offer 30+ programs:**\n\n• B.A. (Hons) – English, History, Economics, Psychology\n• B.Sc. – Physics, Chemistry, Maths, Biotech, CS\n• B.Com – Accounting, Finance, Business\n• BCA – Computer Applications & Data Science\n• Visual Arts – Design, Digital Media\n• M.Com & M.Sc – Postgraduate programs\n\nWhich program interests you?",
  "fees": "💰 **Fee Structure (Approx):**\n\n• B.A. / B.Com: ₹25,000 – ₹40,000/year\n• B.Sc.: ₹30,000 – ₹50,000/year\n• BCA: ₹45,000 – ₹60,000/year\n• PG Programs: ₹35,000 – ₹55,000/year\n\nScholarships available for merit & economically weaker students. Contact us for exact details!",
  "scholarship": "🎓 **Scholarships Available:**\n\n• Merit-based scholarships (top 10%)\n• Government scholarships (SC/ST/OBC)\n• Sports scholarships\n• Need-based financial aid\n\nContact the scholarship cell for more info!",
  "placement": "💼 **Placement Highlights:**\n\n• 90%+ placement rate\n• Top recruiters: TCS, Infosys, Wipro, Deloitte\n• Average package: ₹4-6 LPA\n• Dedicated Training & Placement Cell\n• Industry internship partnerships",
  "hostel": "🏠 **Hostel Facilities:**\n\n• Separate hostels with AC/Non-AC rooms\n• 24/7 security & CCTV\n• Wi-Fi enabled\n• Mess with nutritious meals\n• Fee: ₹50,000 – ₹80,000/year\n\nLimited seats – apply early!",
  "contact": "📞 **Contact Us:**\n\n• Phone: +91 98765 43210\n• Email: admissions@sjrcw.edu.in\n• Address: SJRCW College, Near Sujatha Talkies, Rajajinagar, Bangalore\n• Office: Mon–Sat, 9 AM – 5 PM\n\nOr chat with us on WhatsApp for instant help!",
  "eligibility": "✅ **Eligibility Criteria:**\n\n• UG Programs: 10+2 pass with min 50% marks\n• PG Programs: Relevant bachelor's degree with 50%+\n• Age: No upper age limit\n• Entrance: Based on merit / university entrance exam",
  "document": "📄 **Required Documents:**\n\n• 10th & 12th marksheets\n• Transfer Certificate\n• Migration Certificate\n• Passport-size photos (4)\n• Aadhaar Card / ID proof\n• Caste certificate (if applicable)\n• Income certificate (for scholarships)",
};

const QUICK_OPTIONS = [
  "Admission Process",
  "Courses Offered",
  "Fee Structure",
  "Scholarships",
  "Placements",
  "Hostel Info",
  "Eligibility",
  "Documents Required",
  "Contact Info",
];

function findAnswer(input: string): string {
  const lower = input.toLowerCase();
  if (lower.includes("admission") || lower.includes("apply") || lower.includes("process")) return FAQ["admission"];
  if (lower.includes("course") || lower.includes("program") || lower.includes("subject") || lower.includes("stream")) return FAQ["courses"];
  if (lower.includes("fee") || lower.includes("cost") || lower.includes("price") || lower.includes("charge")) return FAQ["fees"];
  if (lower.includes("scholarship") || lower.includes("financial aid") || lower.includes("concession")) return FAQ["scholarship"];
  if (lower.includes("placement") || lower.includes("job") || lower.includes("recruit") || lower.includes("career")) return FAQ["placement"];
  if (lower.includes("hostel") || lower.includes("accommodation") || lower.includes("room")) return FAQ["hostel"];
  if (lower.includes("contact") || lower.includes("phone") || lower.includes("email") || lower.includes("address")) return FAQ["contact"];
  if (lower.includes("eligib") || lower.includes("criteria") || lower.includes("qualify")) return FAQ["eligibility"];
  if (lower.includes("document") || lower.includes("paper") || lower.includes("certificate")) return FAQ["document"];
  if (lower.includes("hello") || lower.includes("hi") || lower.includes("hey")) return "👋 Hello! Welcome to SJRCW College Admission Assistant!\n\nI can help you with admissions, courses, fees, scholarships, and more. Choose a topic below or type your question!";
  return "🤔 I'm not sure about that. Let me connect you with our admissions team for detailed help!\n\n👇 Click below to chat on WhatsApp for instant support.";
}

function formatMessage(text: string) {
  return text.split("\n").map((line, i) => {
    const bold = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    return <p key={i} className="mb-0.5" dangerouslySetInnerHTML={{ __html: bold }} />;
  });
}

const AdmissionChatbot = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "bot", text: "👋 Hi! I'm the SJRCW Admission Assistant.\n\nI can help you with courses, fees, admissions, scholarships & more!\n\nChoose a topic or type your question below." },
  ]);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { role: "user", text: text.trim() };
    const answer = findAnswer(text);
    const botMsg: Message = { role: "bot", text: answer };
    setMessages((prev) => [...prev, userMsg, botMsg]);
    setInput("");
  };

  const handleQuickOption = (option: string) => {
    handleSend(option);
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary shadow-lg flex items-center justify-center hover:brightness-110 transition-all animate-pulse-soft"
        style={{ boxShadow: "var(--shadow-elevated)" }}
        aria-label="Open Admission Chatbot"
      >
        {open ? (
          <X className="w-6 h-6 text-primary-foreground" />
        ) : (
          <MessageCircle className="w-6 h-6 text-primary-foreground" />
        )}
      </button>

      {/* Chat window */}
      {open && (
        <div className="fixed bottom-24 right-4 sm:right-6 z-50 w-[calc(100vw-2rem)] sm:w-[400px] max-h-[70vh] bg-card rounded-2xl border border-border flex flex-col overflow-hidden" style={{ boxShadow: "var(--shadow-elevated)" }}>
          {/* Header */}
          <div className="bg-primary px-5 py-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center">
              <Bot className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <h3 className="text-primary-foreground font-semibold text-sm">Admission Assistant</h3>
              <p className="text-primary-foreground/60 text-xs">SJRCW College • Online</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[250px] max-h-[400px]">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "bot" && (
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-1">
                    <Bot className="w-5 h-5 text-primary" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-md"
                      : "bg-muted text-foreground rounded-bl-md"
                  }`}
                >
                  {formatMessage(msg.text)}
                </div>
                {msg.role === "user" && (
                  <div className="w-7 h-7 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-1">
                    <User className="w-5 h-5 text-secondary" />
                  </div>
                )}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          {/* Quick options */}
          <div className="px-4 pb-2 flex flex-wrap gap-1.5">
            {QUICK_OPTIONS.map((opt) => (
              <button
                key={opt}
                onClick={() => handleQuickOption(opt)}
                className="text-xs bg-primary/5 border border-border text-foreground px-3 py-1.5 rounded-full hover:bg-primary/10 hover:border-primary/30 transition-colors"
              >
                {opt}
              </button>
            ))}
          </div>

          {/* WhatsApp link */}
          <div className="px-4 pb-2">
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full bg-college-green text-primary-foreground py-2 rounded-lg text-xs font-medium hover:brightness-110 transition-all"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              Chat on WhatsApp for more help
            </a>
          </div>

          {/* Input */}
          <div className="p-3 border-t border-border flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend(input)}
              placeholder="Type your question..."
              className="flex-1 bg-muted border-none rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
            <button
              onClick={() => handleSend(input)}
              className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center hover:brightness-110 transition-all shrink-0"
            >
              <Send className="w-5 h-5 text-primary-foreground" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default AdmissionChatbot;
