import heroCampus from "@/assets/hero-campus.jpg";
import { ArrowRight, Users, Award, BookOpen } from "lucide-react";

const stats = [
  { icon: Users, value: "5,000+", label: "Students" },
  { icon: Award, value: "50+", label: "Awards" },
  { icon: BookOpen, value: "30+", label: "Programs" },
];

const HeroSection = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={heroCampus}
          alt="SJRCW College Campus"
          className="w-full h-full object-cover"
          width={1920}
          height={1080}
        />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)", opacity: 0.88 }} />
      </div>

      <div className="relative container-college px-4 md:px-8 pt-24 pb-16">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-secondary/20 border border-secondary/30 rounded-full px-4 py-1.5 mb-6 animate-fade-up">
            <span className="w-2 h-2 rounded-full bg-secondary animate-pulse-soft" />
            <span className="text-secondary text-sm font-medium">Admissions Open 2025-26</span>
          </div>

          <h1 className="font-heading text-4xl md:text-6xl lg:text-7xl font-bold text-primary-foreground leading-tight mb-6 animate-fade-up" style={{ animationDelay: "0.1s" }}>
            Shape Your Future at{" "}
            <span className="text-gradient-gold">SJRCW College</span>
          </h1>

          <p className="text-primary-foreground/70 text-lg md:text-xl max-w-2xl mb-8 animate-fade-up" style={{ animationDelay: "0.2s" }}>
            Empowering women through excellence in education since 1958. Join a legacy of academic brilliance, innovation, and leadership.
          </p>

          <div className="flex flex-wrap gap-4 mb-12 animate-fade-up" style={{ animationDelay: "0.3s" }}>
            <a
              href="#admissions"
              className="inline-flex items-center gap-2 bg-secondary text-secondary-foreground px-7 py-3.5 rounded-xl font-semibold hover:brightness-110 transition-all shadow-lg"
            >
              Start Your Journey <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="#courses"
              className="inline-flex items-center gap-2 border border-primary-foreground/30 text-primary-foreground px-7 py-3.5 rounded-xl font-semibold hover:bg-primary-foreground/10 transition-all"
            >
              Explore Programs
            </a>
          </div>

          {/* Stats */}
          <div className="flex gap-8 md:gap-12 animate-fade-up" style={{ animationDelay: "0.4s" }}>
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="w-5 h-5 text-secondary mx-auto mb-1" />
                <div className="text-2xl md:text-3xl font-bold text-primary-foreground">{stat.value}</div>
                <div className="text-primary-foreground/50 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
