import aboutCampus from "@/assets/about-campus.jpg";
import { CheckCircle } from "lucide-react";

const highlights = [
  "NAAC 'A+' Accredited Institution",
  "Affiliated to Bangalore University",
  "State-of-the-art Library & Labs",
  "Strong Industry Partnerships",
  "Vibrant Cultural & Sports Life",
  "Dedicated Placement Cell",
];

const AboutSection = () => {
  return (
    <section id="about" className="section-padding bg-background">
      <div className="container-college">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-lg" style={{ boxShadow: "var(--shadow-elevated)" }}>
              <img
                src={aboutCampus}
                alt="SJRCW College Campus Building"
                className="w-full h-[400px] object-cover"
                loading="lazy"
                width={1280}
                height={720}
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-secondary text-secondary-foreground px-6 py-4 rounded-xl font-heading font-bold text-2xl shadow-lg hidden md:block">
              65+ Years
            </div>
          </div>

          {/* Content */}
          <div>
            <span className="text-secondary font-semibold text-sm uppercase tracking-wider">About Us</span>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
              A Legacy of Excellence in Women's Education
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              St. Joseph's Research Centre for Women (SJRCW) College has been a beacon of quality education, empowering women to achieve their dreams. Our institution blends traditional values with modern teaching methodologies to nurture well-rounded individuals ready for the global stage.
            </p>
            <div className="grid sm:grid-cols-2 gap-3">
              {highlights.map((item) => (
                <div key={item} className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-college-green shrink-0" />
                  <span className="text-foreground text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
