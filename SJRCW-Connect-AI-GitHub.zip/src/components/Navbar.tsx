import { useState } from "react";
import { Menu, X, GraduationCap } from "lucide-react";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Courses", href: "#courses" },
  { label: "Admissions", href: "#admissions" },
  { label: "Contact", href: "#contact" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-primary/95 backdrop-blur-md border-b border-primary-foreground/10">
      <div className="container-college flex items-center justify-between h-16 md:h-20 px-4 md:px-8">
        <a href="#home" className="flex items-center gap-2">
          <GraduationCap className="w-8 h-8 text-secondary" />
          <span className="font-heading text-lg md:text-xl font-bold text-primary-foreground">
            SJRCW College
          </span>
        </a>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-primary-foreground/80 hover:text-secondary transition-colors text-sm font-medium"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#admissions"
            className="bg-secondary text-secondary-foreground px-5 py-2 rounded-lg text-sm font-semibold hover:brightness-110 transition-all"
          >
            Apply Now
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => setOpen(!open)}
          className="md:hidden text-primary-foreground"
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-primary border-t border-primary-foreground/10 px-4 pb-4">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="block py-3 text-primary-foreground/80 hover:text-secondary transition-colors text-sm font-medium"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#admissions"
            onClick={() => setOpen(false)}
            className="block mt-2 bg-secondary text-secondary-foreground px-5 py-2 rounded-lg text-sm font-semibold text-center"
          >
            Apply Now
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
